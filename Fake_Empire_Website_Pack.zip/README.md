# Fake Empire

Website structure for GitHub Pages deployment.

- `version-simple/` for a single-page layout
- `version-complete/` for full site experience